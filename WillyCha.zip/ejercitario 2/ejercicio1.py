"""
Hallar el promedio de tres números enteros ingresados por teclado.
"""

num1 = int(input("Ingrese el primer numero entero: "))
num2 = int(input("Ingrese el segundo numero entero "))
num3 = int(input("Ingrese el tercer numero entero "))

promedio = (num1 + num2 + num3)
print("El promedio de los tres numeros enteros es: ", promedio)