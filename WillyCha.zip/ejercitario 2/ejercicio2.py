"""
Hallar el área de un cuadrado.
"""

largo = int (input("Ingresa el largo del cuadrado: "))
ancho = int (input("Ingresa el ancho del cuadrado: ")) 

area = largo * ancho
print("El area es: ", area)