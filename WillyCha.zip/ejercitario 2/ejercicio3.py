"""
Hallar el perímetro de un cuadrado.
"""

lado1 = int (input("Ingresa el valor para lado1: "))
lado2 = int (input("Ingresa el valor para lado2: ")) 
lado3 = int (input("Ingresa el valor para lado3: "))
lado4 = int (input("Ingresa el valor para lado4: "))

perimetro = lado1 + lado2 + lado3 + lado4
print("El perimetro es: ", perimetro)