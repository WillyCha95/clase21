"""
Declara 2 variables numéricas (con el valor que desees), 
he indica cual es mayor de los dos. 
Si son iguales indicarlo también. Vas cambiando los valores para comprobar que funciona.
"""

valor1 = 1200
valor2 = 1000

if (valor1 > valor2):
    print("El valor1", valor1, "es mayor")

elif(valor2 > valor1):
    print("El valor2", valor2, "es mayor")

else:
    print("Ambos valores son iguales")