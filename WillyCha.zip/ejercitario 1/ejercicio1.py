"""
Leer los tres lados de un triángulo escaleno. Calcular su perímetro
"""

lado1 = int (input("Ingresa el valor para lado1: "))
lado2 = int (input("Ingresa el valor para lado2: "))
lado3 = int (input("Ingresa el valor para lado3: "))
perimetro = lado1 + lado2 + lado3
print("El perimetro de un triagulo es: ", perimetro)