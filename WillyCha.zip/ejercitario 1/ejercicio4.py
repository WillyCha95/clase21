# Elaborar un programa que permita leer un solo número e imprima su cubo

numero = int(input("Favor ingresa un numero: "))
cubo = numero * numero * numero #opcional numero **3 
print("El cubo de", numero, "es de:", cubo) # o puede ser numero**3