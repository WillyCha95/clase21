"""
Se desea un programa para convertir metros a pies y pulgadas 
(1 metro = 39.37 pulgadas, 1 pie = 12 pulgadas)
"""

pulgadas = 39.37
pie = 12

metros = int(input("Ingresa el metro que quieres cambiar: "))

