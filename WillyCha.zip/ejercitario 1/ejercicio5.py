"""
Escriba un programa que lea un número negativo e imprima el número y el positivo del mismo
"""

numero = int (input("Ingresa un numero negativo: "))

if (numero < 0):
    print("El numero ingresado es negativo")
else:
    print("El numero ingresado es positivo")